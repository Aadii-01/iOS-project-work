//
//  Testing_purposeTests.swift
//  Testing-purposeTests
//
//  Created by Aditi Mittal on 27/02/25.
//

import Testing
@testable import Testing_purpose

struct Testing_purposeTests {

    @Test func example() async throws {
        // Write your test here and use APIs like `#expect(...)` to check expected conditions.
    }

}
