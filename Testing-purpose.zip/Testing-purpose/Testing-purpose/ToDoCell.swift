//
//  ToDoCell.swift
//  Testing-purpose
//
//  Created by Aditi Mittal on 28/02/25.
//

import UIKit

class ToDoCell: UITableViewCell {
    @IBOutlet weak var toDoTextField: UITextField!
}
