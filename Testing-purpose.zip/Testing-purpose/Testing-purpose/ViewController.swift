//
//  ViewController.swift
//  Testing-purpose
//
//  Created by Aditi Mittal on 27/02/25.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set background color to black
        view.backgroundColor = .black
    }

    @IBAction func menuButton(_ sender: UIButton) {
        let menu = UIAlertController(title: nil, message: nil, preferredStyle: .actionSheet)

        // Change background color of the menu


        // Add menu options with white text
        let editAction = UIAlertAction(title: "Edit", style: .default, handler: { _ in
            print("Edit Tapped")
        })
        let hideAction = UIAlertAction(title: "Hide completed", style: .default, handler: { _ in
            print("Hide Completed Tapped")
        })
        let settingsAction = UIAlertAction(title: "Settings", style: .default, handler: { _ in
            print("Settings Tapped")
        })
        let cancelAction = UIAlertAction(title: "Cancel", style: .cancel)

        // Set text color for actions
        editAction.setValue(UIColor.white, forKey: "titleTextColor")
        hideAction.setValue(UIColor.white, forKey: "titleTextColor")
        settingsAction.setValue(UIColor.white, forKey: "titleTextColor")
        cancelAction.setValue(UIColor.black, forKey: "titleTextColor") // Red for cancel option

        // Add actions to the menu
        menu.addAction(editAction)
        menu.addAction(hideAction)
        menu.addAction(settingsAction)
        menu.addAction(cancelAction)

        // Change background color of action sheet
        if let view = menu.view.subviews.first?.subviews.first?.subviews.first {
            view.backgroundColor = UIColor.darkGray
        }

        present(menu, animated: true, completion: nil)
    }
}
