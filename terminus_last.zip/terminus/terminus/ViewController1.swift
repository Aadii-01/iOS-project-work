//
//  ViewController1.swift
//  terminus
//
//  Created by Apple Lab 21 on 28/02/25.
//

import UIKit

class ViewController1: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
    

    

}
