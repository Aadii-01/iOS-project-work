import UIKit
class ViewController3: UIViewController {
    var exercises = [Exercise]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        view.backgroundColor = .white
        title = "Workout Statistics"
        
        loadExercises()
        if exercises.isEmpty {
            let alert = UIAlertController(title: "No Records", message: "No workout data available.", preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            present(alert, animated: true)
        } else {
            displayStatistics()
        }
    }
    
    private func loadExercises() {
        if let savedData = UserDefaults.standard.data(forKey: "exercises"),
           let savedExercises = try? JSONDecoder().decode([Exercise].self, from: savedData) {
            exercises = savedExercises
        }
    }
    
    private func displayStatistics() {
        let totalDuration = exercises.compactMap { Int($0.duration) }.reduce(0, +)
        let totalWorkouts = exercises.count
        
        let statsLabel = UILabel()
        statsLabel.textColor = .black
        statsLabel.text = "Total Workouts: \(totalWorkouts)\nTotal Duration: \(totalDuration) min"
        statsLabel.textAlignment = .center
        statsLabel.numberOfLines = 0
        statsLabel.frame = CGRect(x: 30, y: 280, width: view.frame.width - 40, height: 100)
        view.addSubview(statsLabel)
    }
}
