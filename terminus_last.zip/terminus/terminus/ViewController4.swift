import UIKit

class ViewController4: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Settings"
        view.backgroundColor = .white
        
        setupUI()
    }
    
    private func setupUI() {
        let settingsLabel = UILabel()
        settingsLabel.text = "Settings Screen"
        settingsLabel.textAlignment = .center
        settingsLabel.font = UIFont.systemFont(ofSize: 20, weight: .bold)
        settingsLabel.frame = CGRect(x: 20, y: 100, width: view.frame.width - 40, height: 50)
        view.addSubview(settingsLabel)
        
        let resetButton = UIButton(type: .system)
        resetButton.setTitle("Reset Data", for: .normal)
        resetButton.addTarget(self, action: #selector(resetData), for: .touchUpInside)
        resetButton.frame = CGRect(x: 50, y: 200, width: view.frame.width - 100, height: 50)
        view.addSubview(resetButton)
    }
    
    @objc private func resetData() {
        let alert = UIAlertController(title: "Reset Data", message: "Are you sure you want to reset all saved exercises?", preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Reset", style: .destructive, handler: { _ in
            UserDefaults.standard.removeObject(forKey: "exercises")
            let confirmationAlert = UIAlertController(title: "Success", message: "All exercise data has been reset.", preferredStyle: .alert)
            confirmationAlert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
            self.present(confirmationAlert, animated: true)
        }))
        
        present(alert, animated: true)
    }
}
