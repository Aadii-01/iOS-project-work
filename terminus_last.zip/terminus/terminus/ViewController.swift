import UIKit

// Struct to store exercise details
struct Exercise: Codable {
    let name: String
    let duration: String
    let notes: String
    let date: Date
}

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    private let table: UITableView = {
        let table = UITableView()
        table.register(UITableViewCell.self, forCellReuseIdentifier: "cell")
        return table
    }()
    
    var exercises = [Exercise]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        title = "Exercise Tracker"
        view.addSubview(table)
        table.dataSource = self
        table.delegate = self
        
        // Load saved exercises
        loadExercises()
        
        navigationItem.rightBarButtonItem = UIBarButtonItem(barButtonSystemItem: .add, target: self, action: #selector(didTapAdd))
        navigationItem.leftBarButtonItem = UIBarButtonItem(title: "Stats", style: .plain, target: self, action: #selector(showStatistics))
    }
    
    override func viewDidLayoutSubviews() {
        super.viewDidLayoutSubviews()
        table.frame = view.bounds
    }
    
    @objc private func didTapAdd() {
        let alert = UIAlertController(title: "New Exercise", message: "Enter exercise details", preferredStyle: .alert)
        
        alert.addTextField { field in field.placeholder = "Exercise Name" }
        alert.addTextField { field in field.placeholder = "Duration (in minutes)"; field.keyboardType = .numberPad }
        alert.addTextField { field in field.placeholder = "Notes (optional)" }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        alert.addAction(UIAlertAction(title: "Next", style: .default, handler: { [weak self] _ in
            guard let fields = alert.textFields,
                  let name = fields[0].text, !name.isEmpty,
                  let duration = fields[1].text, !duration.isEmpty
            else { return }
            
            let notes = fields[2].text ?? ""
            self?.showDatePicker(name: name, duration: duration, notes: notes)
        }))
        
        present(alert, animated: true)
    }
    
    @objc private func showStatistics() {
        let statsVC = ViewController3()
        statsVC.exercises = exercises
        navigationController?.pushViewController(statsVC, animated: true)
    }
    
    private func showDatePicker(name: String, duration: String, notes: String) {
        let datePickerVC = DatePickerViewController()
        datePickerVC.onDateSelected = { [weak self] selectedDate in
            let newExercise = Exercise(name: name, duration: duration, notes: notes, date: selectedDate)
            
            DispatchQueue.main.async {
                self?.exercises.append(newExercise)
                self?.sortExercises()
                self?.saveExercises()
                self?.table.reloadData()
            }
        }
        
        let navigationController = UINavigationController(rootViewController: datePickerVC)
        present(navigationController, animated: true, completion: nil)
    }
    
    private func saveExercises() {
        if let encodedData = try? JSONEncoder().encode(exercises) {
            UserDefaults.standard.set(encodedData, forKey: "exercises")
        }
    }
    
    private func loadExercises() {
        if let savedData = UserDefaults.standard.data(forKey: "exercises"),
           let savedExercises = try? JSONDecoder().decode([Exercise].self, from: savedData) {
            exercises = savedExercises
            sortExercises()
        }
    }
    
    private func sortExercises() {
        exercises.sort { $0.date > $1.date }
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return exercises.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath)
        let exercise = exercises[indexPath.row]
        
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        let dateString = formatter.string(from: exercise.date)
        
        cell.textLabel?.text = "\(exercise.name) - \(exercise.duration) min (\(dateString))"
        return cell
    }
    
    func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
        if editingStyle == .delete {
            DispatchQueue.main.async {
                self.exercises.remove(at: indexPath.row)
                self.saveExercises()
                tableView.deleteRows(at: [indexPath], with: .fade)
            }
        }
    }
}
